/* 
 * File:   main.cpp
 * Author: Miguel Flores
 * Created on February 10th, 2024
 * Purpose: Bingo Project  
 */

#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <string>

// Function prototypes
int generateRandomNumber(int minimum, int maximum);
void initializeGame(int bingoGrid[][5], const int gridSize, const int numbersPerRow, int& roundsPlayed, int& wins, int& numbersDrawn);
void drawNumbers(int bingoGrid[][5], const int gridSize, const int numbersPerRow, int& numbersDrawn);
bool checkForWin(const int bingoGrid[][5], const int gridSize);
void saveGameStatistics(int roundsPlayed, int wins, int numbersDrawn);
void loadGameStatistics(int& roundsPlayed, int& wins, int& numbersDrawn);
void bubbleSortGrid(int bingoGrid[][5], const int gridSize);
void selectionSortGrid(int bingoGrid[][5], const int gridSize);
bool linearSearch(const int bingoGrid[][5], const int gridSize, int target);

int main() {
    srand(time(0)); // Seed for generating random numbers
    const int gridSize = 5; // Number of rows and columns in the bingo grid
    const int numbersPerRow = 5; // Number of numbers per row/column in the grid

    // Variables to track game statistics
    int roundsPlayed = 0; // Number of rounds played
    int wins = 0; // Number of wins
    int numbersDrawn = 0; // Total number of numbers drawn

    // Load previous game statistics from file
    loadGameStatistics(roundsPlayed, wins, numbersDrawn);

    // Initialize the bingo grid with random numbers and display it
    int bingoGrid[gridSize][gridSize];
    initializeGame(bingoGrid, gridSize, numbersPerRow, roundsPlayed, wins, numbersDrawn);

    std::string playerName; // Player's name

    std::cout << "Welcome to Bingo!\n";

    // Validate user input for player's name
    do {
        std::cout << "Please enter your name: ";
        std::getline(std::cin, playerName); // Get player's name
        if (playerName.empty()) {
            std::cout << "Invalid name. Please try again.\n";
        }
    } while (playerName.empty());

    std::cout << "Hello, " << playerName << "! Let's start the game!\n";

    // Display the bingo grid
    std::cout << "Bingo Grid:\n";
    for (int i = 0; i < gridSize; ++i) {
        for (int j = 0; j < gridSize; ++j) {
            std::cout << std::setw(4) << bingoGrid[i][j];
        }
        std::cout << std::endl;
    }

    // Simulate drawing numbers until a win condition is met
    drawNumbers(bingoGrid, gridSize, numbersPerRow, numbersDrawn);

    // Check for a win
    if (checkForWin(bingoGrid, gridSize)) {
        std::cout << "Bingo! " << playerName << " won!\n";
        ++wins; // Increment wins
        
        // if a win is achieved
        std::cout << "Congratulations, " << playerName << "! You're a Bingo champion!\n";
        std::cout << "You're on a roll! Keep it up!\n";
    } else {
        std::cout << "No winner this time. Better luck next time, " << playerName << "!\n";
        
        // if a loss is obtained
        std::cout << "Don't give up, " << playerName << "! Your lucky streak is just around the corner!\n";
        std::cout << "Keep playing, " << playerName << "! You'll get that Bingo soon!\n";
    }

    // Save game statistics to file
    saveGameStatistics(roundsPlayed, wins, numbersDrawn);

    std::cout << "Thanks for playing!\n";
    std::cout << "Would you like to play again? (yes/no): "; 
    std::string playAgain;
    std::cin >> playAgain;
    if (playAgain == "yes") {
        
        // Reset game statistics and start a new game
        roundsPlayed = 0;
        wins = 0;
        numbersDrawn = 0;
        initializeGame(bingoGrid, gridSize, numbersPerRow, roundsPlayed, wins, numbersDrawn);
        main(); // call main to start a new game
    } else {
        std::cout << "Goodbye!\n" << playerName << "!\n";
    }
    
    return 0;
}

// Function to generate a random number between min and max (inclusive)
int generateRandomNumber(int minimum, int maximum) {
    return rand() % (maximum - minimum + 1) + minimum;
}

// Function to initialize the Bingo grid with random numbers
void initializeGame(int bingoGrid[][5], const int gridSize, const int numbersPerRow, int& roundsPlayed, int& wins, int& numbersDrawn) {
    for (int i = 0; i < gridSize; ++i) {
        for (int j = 0; j < gridSize; ++j) {
            bingoGrid[i][j] = generateRandomNumber(j * numbersPerRow + 1, (j + 1) * numbersPerRow);
        }
    }

    // Sort the Bingo grid using both bubble sort and selection sort
    bubbleSortGrid(bingoGrid, gridSize);
    selectionSortGrid(bingoGrid, gridSize);

    // Display the bingo grid
    std::cout << "Bingo Grid:\n";
    for (int i = 0; i < gridSize; ++i) {
        for (int j = 0; j < gridSize; ++j) {
            std::cout << std::setw(4) << bingoGrid[i][j];
        }
        std::cout << std::endl;
    }

    // Initialize game statistics (no longer passed by reference)
    roundsPlayed = 0;
    wins = 0;
    numbersDrawn = 0;
}

// Function to simulate drawing numbers until a win condition is met
void drawNumbers(int bingoGrid[][5], const int gridSize, const int numbersPerRow, int& numbersDrawn) {
    while (true) {
        int drawnNumber = generateRandomNumber(1, gridSize * numbersPerRow); // Generate a random number
        std::cout << "The drawn number is: " << drawnNumber << "\n";
        ++numbersDrawn; // Keep track of the total number of drawn numbers

        // Check if the drawn number matches any cell in the grid
        for (int i = 0; i < gridSize; ++i) {
            for (int j = 0; j < gridSize; ++j) {
                if (bingoGrid[i][j] == drawnNumber) {
                    bingoGrid[i][j] = 0; // Mark the drawn number as matched
                    checkForWin(bingoGrid, gridSize); // Check for win condition (no return needed)
                    return; // Exit the function after marking the number
                }
            }
        }
    }
}

// Function to check for a win condition on the Bingo grid
bool checkForWin(const int bingoGrid[][5], const int gridSize) {
    
    // Check rows and columns for a win
    for (int i = 0; i < gridSize; ++i) {
        bool rowMatch = true, colMatch = true;
        for (int j = 0; j < gridSize; ++j) {
            if (bingoGrid[i][j] != 0) rowMatch = false; // Check rows
            if (bingoGrid[j][i] != 0) colMatch = false; // Check columns
        }
        if (rowMatch || colMatch) return true;
    }

    // Check diagonals for a win
    bool diag1Match = true, diag2Match = true;
    for (int i = 0; i < gridSize; ++i) {
        if (bingoGrid[i][i] != 0) diag1Match = false; // Check main diagonal
        if (bingoGrid[i][gridSize - i - 1] != 0) diag2Match = false; // Check secondary diagonal
    }
    return diag1Match || diag2Match;
}

// Function to save game statistics to a file
void saveGameStatistics(int roundsPlayed, int wins, int numbersDrawn) {
    std::ofstream outputFile("game_statistics.txt");
    if (outputFile.is_open()) {
        outputFile << roundsPlayed << " " << wins << " " << numbersDrawn;
        outputFile.close();
    } else {
        std::cerr << "Error: Could not save game statistics to file.\n";
        exit(EXIT_FAILURE); // Exit the program with failure status
    }
}

// Function to load game statistics from a file
void loadGameStatistics(int& roundsPlayed, int& wins, int& numbersDrawn) {
    std::ifstream inputFile("game_statistics.txt");
    if (inputFile.is_open()) {
        inputFile >> roundsPlayed >> wins >> numbersDrawn;
        inputFile.close();
    }
}

// Function to perform Bubble Sort on each row of the Bingo grid
void bubbleSortGrid(int bingoGrid[][5], const int gridSize) {
    for (int i = 0; i < gridSize; ++i) {
        for (int j = 0; j < gridSize - 1; ++j) {
            for (int k = 0; k < gridSize - j - 1; ++k) {
                if (bingoGrid[i][k] > bingoGrid[i][k + 1]) {
                    
                    // Swap elements if they are in the wrong order
                    int temp = bingoGrid[i][k];
                    bingoGrid[i][k] = bingoGrid[i][k + 1];
                    bingoGrid[i][k + 1] = temp;
                }
            }
        }
    }
}

// Function to perform Selection Sort on each row of the Bingo grid
void selectionSortGrid(int bingoGrid[][5], const int gridSize) {
    for (int i = 0; i < gridSize; ++i) {
        for (int j = 0; j < gridSize - 1; ++j) {
            int minIndex = j;
            for (int k = j + 1; k < gridSize; ++k) {
                if (bingoGrid[i][k] < bingoGrid[i][minIndex]) {
                    minIndex = k;
                }
            }
            
            // Swap elements if necessary
            if (minIndex != j) {
                int temp = bingoGrid[i][j];
                bingoGrid[i][j] = bingoGrid[i][minIndex];
                bingoGrid[i][minIndex] = temp;
            }
        }
    }
}

// Function to perform linear search for a target number in the Bingo grid
bool linearSearch(const int bingoGrid[][5], const int gridSize, int target) {
    for (int i = 0; i < gridSize; ++i) {
        for (int j = 0; j < gridSize; ++j) {
            if (bingoGrid[i][j] == target) { 
                return true; // Target number found
            }
        }
    }
    return false; // Target number not found
}