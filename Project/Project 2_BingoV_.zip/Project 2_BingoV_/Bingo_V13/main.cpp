/* 
 * File:   main.cpp
 * Author: Miguel Flores
 * Created on February 9th, 2024
 * Purpose: Bingo Project  
 */

#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <string>

// Function prototypes
int genRnd(int min, int max);
void initializeGame(int bngGd[][5], const int grdSz, const int numsPrR, int& rndsPl, int& wins, int& numsDrwn);
void drawNumbers(int bngGd[][5], const int grdSz, const int numsPrR, int& numsDrwn);
bool checkForWin(const int bngGd[][5], const int grdSz);
void saveGameStatistics(int rndsPl, int wins, int numsDrwn);
void bubbleSortGrid(int bngGd[][5], const int grdSz); // New function prototype

int main() {
    srand(time(0)); // Prepare for generating random numbers
    const int grdSz = 5; // Number of rows and columns in the bingo grid
    const int numsPrR = 5; // Number of numbers per row/column in the grid

    // Variables to track game statistics
    int rndsPl = 0; // Number of rounds played
    int wins = 0; // Number of wins
    int numsDrwn = 0; // Total number of numbers drawn

    // Read game statistics from a file
    std::ifstream inF("game_stats.txt");
    if (inF.is_open()) {
        inF >> rndsPl >> wins >> numsDrwn;
        inF.close();
    } else {
        std::cout << "Could not open file. Starting with default game statistics.\n";
    }

    // Initialize the bingo grid with random numbers and display it
    int bngGd[grdSz][grdSz];
    initializeGame(bngGd, grdSz, numsPrR, rndsPl, wins, numsDrwn);

    std::string plyrNm; // Player can input their name

    std::cout << "Welcome to Bingo!\n";

    // Validate user input for player's name
    do {
        std::cout << "Please enter your name: ";
        std::getline(std::cin, plyrNm); // Get player's name
        if (plyrNm.empty()) {
            std::cout << "Invalid name. Please try again.\n";
        }
    } while (plyrNm.empty());

    std::cout << "Hello, " << plyrNm << "! Let's start the game!\n";

    // Display the bingo grid
    std::cout << "Bingo Grid:\n";
    for (int i = 0; i < grdSz; ++i) {
        for (int j = 0; j < grdSz; ++j) {
            std::cout << std::setw(4) << bngGd[i][j];
        }
        std::cout << std::endl;
    }

    // Simulate drawing numbers until a win condition is met
    drawNumbers(bngGd, grdSz, numsPrR, numsDrwn);

    // Check for a win
    if (checkForWin(bngGd, grdSz)) {
        std::cout << "Bingo! " << plyrNm << " won!\n";
        ++wins; // Increment wins
    } else {
        std::cout << "No winner this time. Better luck next time!\n";
    }

    // Save game statistics to a file
    saveGameStatistics(rndsPl, wins, numsDrwn);

    std::cout << "Thanks for playing!\n";
    return 0;
}

// Function to generate a random number between min and max (inclusive)
int genRnd(int min, int max) {
    return rand() % (max - min + 1) + min;
}

// Function to initialize the Bingo grid with random numbers
void initializeGame(int bngGd[][5], const int grdSz, const int numsPrR, int rndsPl, int wins, int numsDrwn) {
    for (int i = 0; i < grdSz; ++i) {
        for (int j = 0; j < grdSz; ++j) {
            bngGd[i][j] = genRnd(j * numsPrR + 1, (j + 1) * numsPrR);
        }
    }

    // Sort the Bingo grid using bubble sort
    bubbleSortGrid(bngGd, grdSz);

    // Display the bingo grid
    std::cout << "Bingo Grid:\n";
    for (int i = 0; i < grdSz; ++i) {
        for (int j = 0; j < grdSz; ++j) {
            std::cout << std::setw(4) << bngGd[i][j];
        }
        std::cout << std::endl;
    }

    // Initialize game statistics (no longer passed by reference)
    rndsPl = 0;
    wins = 0;
    numsDrwn = 0;
}

// Function to simulate drawing numbers until a win condition is met
bool drawNumbers(int bngGd[][5], const int grdSz, const int numsPrR, int& numsDrwn) {
    while (true) {
        int drwnNum = genRnd(1, grdSz * numsPrR); // Generate a random number
        std::cout << "The drawn number is: " << drwnNum << "\n";
        ++numsDrwn; // Keep track of the total number of drawn numbers

        // Check if the drawn number matches any cell in the grid
        for (int i = 0; i < grdSz; ++i) {
            for (int j = 0; j < grdSz; ++j) {
                if (bngGd[i][j] == drwnNum) {
                    bngGd[i][j] = 0; // Mark the drawn number as matched
                    return checkForWin(bngGd, grdSz); // Return true if a win condition is met
                }
            }
        }
    }
}

// Function to check for a win condition on the Bingo grid
bool checkForWin(const int bngGd[][5], const int grdSz) {
    // Check rows and columns for a win
    for (int i = 0; i < grdSz; ++i) {
        bool rwMtch = true, colMtch = true;
        for (int j = 0; j < grdSz; ++j) {
            if (bngGd[i][j] != 0) rwMtch = false; // Check rows
            if (bngGd[j][i] != 0) colMtch = false; // Check columns
        }
        if (rwMtch || colMtch) return true;
    }

    // Check diagonals for a win
    bool diag1Mtch = true, diag2Mtch = true;
    for (int i = 0; i < grdSz; ++i) {
        if (bngGd[i][i] != 0) diag1Mtch = false; // Check main diagonal
        if (bngGd[i][grdSz - i - 1] != 0) diag2Mtch = false; // Check secondary diagonal
    }
    return diag1Mtch || diag2Mtch;
}

// Function to save game statistics to a file
void saveGameStatistics(int rndsPl, int wins, int numsDrwn) {
    std::ofstream outF("game_stats.txt");
    if (outF.is_open()) {
        outF << rndsPl << " " << wins << " " << numsDrwn;
        outF.close();
    } else {
        std::cout << "Could not save game statistics to file.\n";
    }
}

// Function to perform Bubble Sort on each row of the Bingo grid
void bubbleSortGrid(int bngGd[][5], const int grdSz) {
    for (int i = 0; i < grdSz; ++i) {
        for (int j = 0; j < grdSz - 1; ++j) {
            for (int k = 0; k < grdSz - j - 1; ++k) {
                if (bngGd[i][k] > bngGd[i][k + 1]) {
                    // Swap elements if they are in the wrong order
                    int temp = bngGd[i][k];
                    bngGd[i][k] = bngGd[i][k + 1];
                    bngGd[i][k + 1] = temp;
                }
            }
        }
    }
} 